function checklength(){
	var elMsg = document.getElementById('msgBox');
	
	if(this.value.length < 8){
		elMsg.textContent='Username must be between 8 and 24 characters';	
	}else{
		elMsg.textContent='';		
	}
}
function checklength2(){
	var elMsg = document.getElementById('msgBox');
	
	if(this.value.length < 8){
		elMsg.textContent=' Password must be between 8 and 24 characters';	
	}else{
		elMsg.textContent='';		
	}
}
var elPassword =document.getElementById('pswid');
var elUsername =document.getElementById('nameid')
elPassword.onblur =checklength;
elUsername.onblur=checklength2;

function Redirect(){
	if(elPassword.value.length>=8 && elUsername.value.length>=8){ 
		setTimeout(function(){
			window.location = './SignIn.html';
		},2000);
	}
}

function Redirect2(){
	setTimeout(function(){
		window.location = './UX challenge.html';
	},1000);
}

/*$(function(){
	$('#submitid').click(function(){
		$(this).html('<img src="img/logo-google.svg"/>');
		return false;
	})
})*/